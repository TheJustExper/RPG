import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class index {
	public static void main(String[] args) {
		//Create and set up the window.
	      Window window = new Window(1920 / 3, 1080 / 3);
	}
}
