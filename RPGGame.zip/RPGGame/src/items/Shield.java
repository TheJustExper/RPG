package items;

public class Shield extends Item {

    public Shield() {
        super("Shield", 20);
    }
}
