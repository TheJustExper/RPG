package items;

import java.util.ArrayList;

public class ItemManager {
    private ArrayList<Item> entities = new ArrayList<>();

    public ItemManager() {
        this.entities.add(new Sword());
        this.entities.add(new Axe());
        this.entities.add(new Shield());
    }

    public ArrayList<Item> getEntites() {
        return this.entities;
    }
}
