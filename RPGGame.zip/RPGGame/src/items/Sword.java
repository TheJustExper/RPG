package items;

public class Sword extends Item {

    public Sword() {
        super("Sword", 80);
    }

}
