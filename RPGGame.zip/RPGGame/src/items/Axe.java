package items;

public class Axe extends Item {
    public Axe() {
        super("Axe", 90);
    }
}
