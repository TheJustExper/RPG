package items;

public class Item {

    private final String name;
    private final int damage;
    private int health = (int) Math.floor(Math.random() * 100);

    public Item(String name, int damage) {
        this.name = name;
        this.damage = damage;
    }

    public String getName() {
        return name;
    }

    public int getDamage() {
        return damage;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        return health;
    }
}
