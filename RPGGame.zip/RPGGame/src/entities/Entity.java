package entities;

public class Entity {
	private String name;
	private int health;
	
	public Entity(String name) {
		this.name = name;
		this.health = 100;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getHealth() {
		return this.health;
	}

}
