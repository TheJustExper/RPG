package entities;

public class Orc extends Entity {

    public Orc() {
        super("Orc");
    }

}

