package entities;

public class Dragon extends Entity {

	public Dragon() {
		super("Dragon");
	}

}
