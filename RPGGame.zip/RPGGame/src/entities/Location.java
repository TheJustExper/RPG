package entities;

public interface Location {}
