package entities;

import java.util.ArrayList;

public class EntityManager {
	private ArrayList<Entity> entities = new ArrayList<>();
	
	public EntityManager() {
		this.entities.add(new Dragon());
		this.entities.add(new Orc());
	}
	
	public ArrayList<Entity> getEntites() {
		return this.entities;
	}
}
