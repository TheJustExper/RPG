package spells;

import spells.SpellBook;

public class Player {
	
	private SpellBook spellBook;
	private int mana;
	
	public Player() {
		this.spellBook = new SpellBook();
		this.mana = 10000;
	}
	
	public SpellBook getSpellBook() {
		return this.spellBook;
	}
	
	public int getMana() {
		return this.mana;
	}
	
	public void minusMana(int a) {
		this.mana -= a;
	}
	
	
}
