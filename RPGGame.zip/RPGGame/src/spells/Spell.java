package spells;

import java.awt.event.ActionListener;

import javax.swing.JLabel;

public abstract class Spell {
	private String name;
	private int manaCost = 50;
	
	public Spell(String n, int manaCost) {
		this.name = n;
		this.manaCost = manaCost;
	}
	
	public String getName() {
		return name;
	}
	
	public int getManaCost() {
		return manaCost;
	}

	
}
