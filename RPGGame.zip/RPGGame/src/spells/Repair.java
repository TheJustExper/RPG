package spells;

public class Repair extends Spell {

	public Repair() {
		super("Repair", 80);
	}
	
}
