package spells;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

public class Fireball extends Spell implements Location {

	public Fireball() {
		super("Fireball", 20);
	}

}
