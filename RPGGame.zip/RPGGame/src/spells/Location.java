package spells;

public interface Location {}
