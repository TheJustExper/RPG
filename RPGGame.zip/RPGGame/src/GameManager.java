import entities.Dragon;
import entities.Entity;
import entities.EntityManager;
import items.ItemManager;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import spells.Player;
import spells.Spell;

import java.lang.reflect.Array;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class GameManager {
	
	public Player player = new Player();
	public EntityManager entityManager = new EntityManager();
	public ItemManager itemManager = new ItemManager();
	public Label manaText = new Label();
	public StackPane root = new StackPane();
    public Scene scene = new Scene(root, 450, 250);
    public Stage primaryStage;
	public Random rand = new Random();
    public int[] locations = IntStream.range(0, 41).map(i -> rand.nextInt()).toArray();
	
	public GameManager(Stage primaryStage) {
		this.update();
		this.primaryStage = primaryStage;
        
        primaryStage.setTitle("Game window");
        primaryStage.setScene(scene);
        primaryStage.show();
	}
	
	public void update() {
		manaText.setText("Mana: " + player.getMana());
		
		ChoiceBox cb = new ChoiceBox();
		cb.getItems().addAll("Creature", "Location", "Item");
    	
    	VBox vbox = new VBox(5); 
    	vbox.getChildren().addAll(manaText, cb);	
    	vbox.setAlignment(Pos.CENTER);
    	
        player.getSpellBook().getSpells().forEach(spell -> {
        	Button button = new Button();
            button.setText(spell.getName());
     
            button.setOnAction(event -> {
				if (player.getMana() >= spell.getManaCost()) {
					if (cb.getSelectionModel().getSelectedIndex() != -1) {
						if (cb.getSelectionModel().getSelectedIndex() == 0) {
							if (spell.getName() == "Healing") {
								openModal("creature", spell);
							}
						}

						if (cb.getSelectionModel().getSelectedIndex() == 1) {
							if (spell.getName() == "Fireball") {
								openModal("location", spell);
							}
						}

						if (cb.getSelectionModel().getSelectedIndex() == 2) {
							if (spell.getName() == "Repair") {
								System.out.println("Chosen to repair an item");
								openModal("item", spell);
							}
						}

					}
				} else {
					System.out.println("Not enough mana");
				}
			});
        
            vbox.getChildren().add(button);
        });
        
        root.getChildren().add(vbox);
	}

	public void openModal(String type, Spell spell) {
		final Stage dialog = new Stage();
		dialog.initModality(Modality.APPLICATION_MODAL);
		dialog.initOwner(primaryStage);

		VBox vbox = new VBox(5);
		vbox.setAlignment(Pos.CENTER);

		TextField input = new TextField();
		Button button = new Button();
		button.setText("Cast spell");

		switch(type) {
			case "creature":
				ChoiceBox cb = new ChoiceBox();
				cb.getItems().addAll(Stream.of(entityManager.getEntites().toArray()).map((val) -> val.getClass().getName().split("entities.")[1]).toArray());

				button.setOnAction(event -> {
					if (cb.getSelectionModel().getSelectedIndex() == -1) return;
					player.minusMana(spell.getManaCost());
					manaText.setText("Mana: " + player.getMana());
					System.out.println("Cast spell on: " + cb.getSelectionModel().getSelectedItem());
				});

				vbox.getChildren().addAll(new Text("Choose a creature"), cb, button);
				break;

			case "location":
				button.setOnAction(event -> {
					if (!(input.getText().matches("^[0-9]*$"))) return;
					int val = Integer.valueOf(input.getText());
					if (val >= 1 && val <= 41) {
						player.minusMana(spell.getManaCost());
						manaText.setText("Mana: " + player.getMana());
						System.out.println("Cast spell on location: " + input.getText());
					}
				});

				vbox.getChildren().addAll(new Text("Choose a integer for the location (Integer needs to be in range 1 - 25)"), input, button);
				break;

			case "item":
				ChoiceBox box = new ChoiceBox();
				box.getItems().addAll(Stream.of(itemManager.getEntites().toArray()).map((val) -> val.getClass().getName().split("items.")[1]).toArray());

				button.setOnAction(event -> {
					if (box.getSelectionModel().getSelectedIndex() == -1) return;
					int health = itemManager.getEntites().get(box.getSelectionModel().getSelectedIndex()).getHealth();
					if (health < 100) {
						player.minusMana(spell.getManaCost());
						manaText.setText("Mana: " + player.getMana());

						if (health + 30 > 100) {
							itemManager.getEntites().get(box.getSelectionModel().getSelectedIndex()).setHealth(100);
						} else {
							itemManager.getEntites().get(box.getSelectionModel().getSelectedIndex()).setHealth(health + 30);
						}

						health = itemManager.getEntites().get(box.getSelectionModel().getSelectedIndex()).getHealth();
						System.out.println("Cast repair spell on " + box.getSelectionModel().getSelectedItem() + " health set to " + health);
					} else {
						System.out.println("Item is already at 100% health");
					}
				});

				vbox.getChildren().addAll(new Text("Choose a item"), box, button);
				break;
		}

		Scene dialogScene = new Scene(vbox, 300, 200);
		dialog.setScene(dialogScene);
		dialog.show();
	}
}
